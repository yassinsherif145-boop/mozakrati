package com.mzk.app;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;

public class MainActivity extends Activity {
    WebView wv;
    ValueCallback<Uri[]> chooser;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Notifs.ensure(this);
        wv = new WebView(this);
        WebSettings s = wv.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        wv.addJavascriptInterface(new Bridge(this), "Android");
        wv.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (chooser != null) chooser.onReceiveValue(null);
                chooser = cb;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                startActivityForResult(i, 7);
                return true;
            }
        });
        setContentView(wv);
        load();
        askPermissions();
    }

    // بيحمّل الصفحة. لو التحديث المحمّل بوظ ومفتحش في 8 ثواني، بيرجع للنسخة الأصلية لوحده
    void load() {
        final String url = Util.pageUrl(this);
        final SharedPreferences p = getSharedPreferences("mzk", MODE_PRIVATE);
        if (!url.equals(Util.ASSET)) {
            p.edit().putBoolean("pending", true).apply();
            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (p.getBoolean("pending", false)) {
                        p.edit().putBoolean("pending", false).apply();
                        Util.resetOverride(MainActivity.this);
                        wv.loadUrl(Util.ASSET);
                    }
                }
            }, 8000);
        }
        wv.loadUrl(url);
    }

    void reload() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                load();
            }
        });
    }

    void askPermissions() {
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 5);
        }
        SharedPreferences p = getSharedPreferences("mzk", MODE_PRIVATE);
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        if (!p.getBoolean("askedBatt", false) && !pm.isIgnoringBatteryOptimizations(getPackageName())) {
            p.edit().putBoolean("askedBatt", true).apply();
            try {
                Intent i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
                i.setData(Uri.parse("package:" + getPackageName()));
                startActivity(i);
            } catch (Exception e) {
            }
        }
    }

    void pickTone() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    Intent i = new Intent(RingtoneManager.ACTION_RINGTONE_PICKER);
                    i.putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALARM);
                    i.putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true);
                    i.putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, false);
                    i.putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "اختار نغمة المنبه");
                    String s = getSharedPreferences("mzk", MODE_PRIVATE).getString("tone", "");
                    if (!s.isEmpty()) {
                        i.putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, Uri.parse(s));
                    }
                    startActivityForResult(i, 8);
                } catch (Exception e) {
                }
            }
        });
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == 7 && chooser != null) {
            Uri[] r = null;
            if (res == RESULT_OK && data != null && data.getData() != null) {
                r = new Uri[]{data.getData()};
            }
            chooser.onReceiveValue(r);
            chooser = null;
        }
        if (req == 8 && res == RESULT_OK && data != null) {
            Uri u = data.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI);
            getSharedPreferences("mzk", MODE_PRIVATE).edit()
                    .putString("tone", u == null ? "" : u.toString()).apply();
            wv.post(new Runnable() {
                @Override
                public void run() {
                    wv.evaluateJavascript("try{toneSet()}catch(e){}", null);
                }
            });
        }
    }

    @Override
    public void onBackPressed() {
        if (wv != null && wv.canGoBack()) {
            wv.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
